/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.pushplatform.sdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.pushplatform.sdk";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String SDK_VERSION = "2.0.4";
}
